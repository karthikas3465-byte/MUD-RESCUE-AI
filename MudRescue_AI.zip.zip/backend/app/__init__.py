"""MudRescue local API."""
