# MudRescue AI: always-online Render deployment

This folder is a clean deployment copy of the existing application. It contains the unchanged FastAPI backend, built React frontend, bundled demo assets, and the same YOLO11n weights. It contains **no local uploads, evidence, or SQLite database**. The original local app and its data remain untouched.

## Public URL and data

Render assigns a stable `https://<service>.onrender.com` URL to the service. Anyone can open that URL without a Render account. HTTPS is the secure form of HTTP; do not disable it. **This prototype has no visitor authentication.** Anyone with the public URL can call its API and inspect missions, uploaded media, and review records. Upload only material approved for public access. The Render deployment starts with an empty database and stores its future data on the persistent disk at `/var/data`.

## Configuration

- `Dockerfile` builds a CPU-only Python 3.11 application image. It serves the built frontend and FastAPI API from one process using Render's `PORT` environment variable.
- `render.yaml` requests a Docker web service on Render's `1c-2g` plan, a 10 GB persistent disk, and `/api/health` checks. The disk stores SQLite, uploads, and generated evidence through `MUDRESCUE_DATA_DIR=/var/data`.
- `.gitignore` deliberately **does not** exclude `models/yolo11n.pt`, `frontend/dist`, or bundled demo assets, because they must be present in the private deployment repository.
- The model architecture, weights, frontend, API routes, and database schema are unchanged.

## Publish after signing in

1. Create a **private** GitHub repository for this deployment copy. Upload or push this folder's contents, including `render.yaml`, `Dockerfile`, `backend/`, `frontend/dist/`, `models/yolo11n.pt`, and `demo/`. Do not upload any local `.runtime/`, `uploads/`, `evidence/`, or SQLite files.
2. In the signed-in Render dashboard, create a **Blueprint** from that private repository. Review the proposed `1c-2g` web service and 10 GB disk before confirming billing. The service name may need to be unique.
3. Watch the build and deploy logs until the web service is Live and `/api/health` returns 200. Open the assigned `.onrender.com` URL and run the bundled demo analysis. Confirm that the page, assets, API, model inference, and review export work.
4. Restart the service once, then verify that a review decision and generated evidence remain available. This checks the persistent disk, not merely the homepage.

The requested 2 GB plan may need adjustment if the model or large videos exceed memory. Do not increase to a more expensive plan without checking actual Render memory metrics and approving the cost. Current plan and disk prices are on [Render's pricing page](https://render.com/pricing).

The free Render service is unsuitable for this always-online, stateful app because it sleeps when idle and cannot attach a persistent disk. See [Render's free-plan limits](https://render.com/docs/free) and [persistent disk documentation](https://render.com/docs/disks).

## Local smoke test

The source copy can be checked locally without Docker:

```powershell
$env:MUDRESCUE_DATA_DIR = 'C:\path\to\separate-smoke-runtime'
python -m uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8002
```

Then request `http://127.0.0.1:8002/api/health` and run a bundled demo analysis. Docker itself must still build and pass health checks on Render; a local Python run cannot prove the Linux image is correct.
